package com.example.flightsearch.data

enum class ScreenType {
    Home, AirportDetail, AutoComplete
}